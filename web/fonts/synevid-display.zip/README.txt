SynEvid Display Brand Font (Exact Michroma match)
