SynEvid Slab Font (Rebranded for SynEvid Code Autopsy Engine)
